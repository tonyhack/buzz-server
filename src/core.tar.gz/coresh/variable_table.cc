//
// Summary: buzz source code.
//
// Author: Tony.
// Email: tonyjobmails@gmail.com.
// Last modify: 2012-12-27 14:29:00.
// File name: variable_table.cc
//
// Description:
// Define class VariableTable.
//

#include "coresh/variable_table.h"

namespace coresh {

VariableTable VariableTableSingleton::variables_;

}  // namespace coresh

